# samplepkg 1.0
A tiny source tree used to exercise VybOS real-package realization
(archive inflate + tar extract -> flat content-addressed store).
